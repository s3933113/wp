<?php
$title = "Library";
include('includes/header.inc');
?>
<h1>Welcome to the Library</h1>
<?php
include('includes/nav.inc');
?>
<?php
include('includes/footer.inc');
?>